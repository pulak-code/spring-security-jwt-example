package genaidemopoc.ecommerceproj.jwtspringsecurity.usersvc.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import genaidemopoc.ecommerceproj.jwtspringsecurity.usersvc.model.UserEntity;
import genaidemopoc.ecommerceproj.jwtspringsecurity.usersvc.repository.UserRepository;
import genaidemopoc.ecommerceproj.jwtspringsecurity.usersvc.service.UserService;

@RestController
@RequestMapping("/api/test")
public class TestController {
    
    private static final Logger logger = LoggerFactory.getLogger(TestController.class);
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private UserService userService;
    
    @GetMapping("/hello")
    public ResponseEntity<String> hello() {
        return ResponseEntity.ok("Hello from test controller");
    }
    
    @GetMapping("/check-admin-users")
    public ResponseEntity<Map<String, Object>> checkAdminUsers() {
        logger.info("Checking admin users in the database");
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            // Check admin@example.com
            Optional<UserEntity> adminUserOpt = userRepository.findByEmail("admin@example.com");
            if (adminUserOpt.isPresent()) {
                UserEntity adminUser = adminUserOpt.get();
                Map<String, Object> adminInfo = new HashMap<>();
                adminInfo.put("userId", adminUser.getId());
                adminInfo.put("roles", adminUser.getRoles());
                response.put("admin@example.com", adminInfo);
            } else {
                response.put("admin@example.com", "User not found");
            }
            
            // Check admin99@example.com
            Optional<UserEntity> admin99UserOpt = userRepository.findByEmail("admin99@example.com");
            if (admin99UserOpt.isPresent()) {
                UserEntity admin99User = admin99UserOpt.get();
                Map<String, Object> admin99Info = new HashMap<>();
                admin99Info.put("userId", admin99User.getId());
                admin99Info.put("roles", admin99User.getRoles());
                response.put("admin99@example.com", admin99Info);
            } else {
                response.put("admin99@example.com", "User not found");
            }
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error checking admin users: {}", e.getMessage(), e);
            response.put("error", e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }
    
    @PostMapping("/create-admin")
    public ResponseEntity<Map<String, Object>> createAdmin(@RequestBody(required = false) Map<String, String> request) {
        Map<String, Object> response = new HashMap<>();
        String email = request != null && request.containsKey("email") ? request.get("email") : "admin@example.com";
        String password = request != null && request.containsKey("password") ? request.get("password") : "Password@1234";
        String name = request != null && request.containsKey("name") ? request.get("name") : "Admin User";
        
        logger.info("Creating admin user: {}", email);
        
        try {
            Optional<UserEntity> existingUser = userRepository.findByEmail(email);
            
            if (existingUser.isPresent()) {
                response.put("userExists", true);
                response.put("message", "User already exists");
                
                UserEntity user = existingUser.get();
                response.put("userId", user.getId());
                response.put("email", user.getEmail());
                response.put("roles", user.getRoles());
                
                return ResponseEntity.ok(response);
            }
            
            UserEntity user = new UserEntity();
            user.setEmail(email);
            user.setPassword(passwordEncoder.encode(password));
            user.setName(name);
            
            List<String> roles = new ArrayList<>();
            roles.add("ROLE_ADMIN");
            user.setRoles(roles);
            
            UserEntity savedUser = userRepository.save(user);
            
            response.put("userCreated", true);
            response.put("userId", savedUser.getId());
            response.put("email", savedUser.getEmail());
            response.put("name", savedUser.getName());
            response.put("roles", savedUser.getRoles());
            
            logger.info("Admin user created: {}", savedUser.getEmail());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error creating admin user: {}", e.getMessage(), e);
            response.put("error", e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }
    
    @GetMapping("/reset-admin-password")
    public ResponseEntity<Map<String, Object>> resetAdminPassword() {
        Map<String, Object> response = new HashMap<>();
        logger.info("Resetting admin password");
        
        try {
            String rawPassword = "Password@1234";
            
            // Reset admin@example.com
            Optional<UserEntity> adminOpt = userRepository.findByEmail("admin@example.com");
            if (adminOpt.isPresent()) {
                UserEntity admin = adminOpt.get();
                String encodedPassword = passwordEncoder.encode(rawPassword);
                admin.setPassword(encodedPassword);
                
                // Ensure admin has ROLE_ADMIN
                if (admin.getRoles() == null) {
                    admin.setRoles(new ArrayList<>());
                }
                if (!admin.getRoles().contains("ROLE_ADMIN")) {
                    admin.getRoles().add("ROLE_ADMIN");
                }
                
                userRepository.save(admin);
                
                response.put("adminResetSuccess", true);
                response.put("adminEmail", admin.getEmail());
                response.put("adminRoles", admin.getRoles());
                logger.info("Admin user password reset successfully");
            } else {
                response.put("adminResetSuccess", false);
                response.put("adminError", "Admin user not found");
                logger.info("Admin user not found for password reset");
            }
            
            // Reset admin99@example.com
            Optional<UserEntity> admin99Opt = userRepository.findByEmail("admin99@example.com");
            if (admin99Opt.isPresent()) {
                UserEntity admin99 = admin99Opt.get();
                String encodedPassword = passwordEncoder.encode(rawPassword);
                admin99.setPassword(encodedPassword);
                
                // Ensure admin99 has ROLE_ADMIN
                if (admin99.getRoles() == null) {
                    admin99.setRoles(new ArrayList<>());
                }
                if (!admin99.getRoles().contains("ROLE_ADMIN")) {
                    admin99.getRoles().add("ROLE_ADMIN");
                }
                
                userRepository.save(admin99);
                
                response.put("admin99ResetSuccess", true);
                response.put("admin99Email", admin99.getEmail());
                response.put("admin99Roles", admin99.getRoles());
                logger.info("Admin99 user password reset successfully");
            } else {
                response.put("admin99ResetSuccess", false);
                response.put("admin99Error", "Admin99 user not found");
                logger.info("Admin99 user not found for password reset");
            }
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error resetting admin passwords: {}", e.getMessage(), e);
            response.put("error", e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }
    
    @GetMapping("/mongo-info")
    public ResponseEntity<Map<String, Object>> getMongoInfo() {
        Map<String, Object> response = new HashMap<>();
        logger.info("Getting MongoDB collections and user data");
        
        try {
            // Get users collection data
            List<UserEntity> allUsers = userRepository.findAll();
            List<Map<String, Object>> usersList = new ArrayList<>();
            
            for (UserEntity user : allUsers) {
                Map<String, Object> userMap = new HashMap<>();
                userMap.put("id", user.getId());
                userMap.put("email", user.getEmail());
                userMap.put("name", user.getName());
                userMap.put("roles", user.getRoles());
                usersList.add(userMap);
            }
            
            response.put("users", usersList);
            response.put("userCount", usersList.size());
            
            logger.info("Found {} users in MongoDB", usersList.size());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error getting MongoDB info: {}", e.getMessage(), e);
            response.put("error", e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }
} 