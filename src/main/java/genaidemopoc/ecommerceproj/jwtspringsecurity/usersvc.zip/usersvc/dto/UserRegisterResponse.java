package genaidemopoc.ecommerceproj.jwtspringsecurity.usersvc.dto;

public class UserRegisterResponse {

}
