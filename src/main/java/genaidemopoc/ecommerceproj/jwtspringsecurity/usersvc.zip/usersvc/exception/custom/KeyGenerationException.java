package genaidemopoc.ecommerceproj.jwtspringsecurity.usersvc.exception.custom;

public class KeyGenerationException extends RuntimeException {

	public KeyGenerationException(String msg, Exception e) {
		
	}

	private static final long serialVersionUID = 11L;

}
